#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"

int ls_files()
{
  char *argv[] = {"ls", 0};
  int start_time = uptime();
  if (!fork()){
    if (exec("../ls", argv) < 0){
      printf("dirtest ls failed\n");
      exit(1);
    }
    exit(0);
  }
  else{
    int status;
    wait(&status);
    if (status != 0)
      exit(status);
  }
  int end_time = uptime();
  if (end_time < start_time){
    return -1;
  }
  return end_time - start_time;
}

int create_files()
{
  int start_time = uptime(),fd = 0;
  char filename[4];
  filename[1] = '_';
  filename[3] = '\0';
  for (int i = 0x61; i <= 0x6c; ++i){
    filename[0] = i;
    for (int j = 0x41; j <= 0x4c; ++j){
      filename[2] = j;
      printf("create file named %s\n",filename);
      if ((fd = open(filename, O_CREATE)) < 0)
      {
        close(fd);
        printf("create empty file failed\n");
        exit(1);
      }
      close(fd);
    }
  }
  int end_time = uptime();
  if (end_time < start_time){
    return -1;
  }
  return end_time - start_time;
}

void remove_files()
{
  char filename[4];
  filename[1] = '_'; 
  filename[3] = '\0';
  for (int i = 0x61; i <= 0x6c; ++i)
  {
    filename[0] = i;
    for (int j = 0x41; j <= 0x4c; ++j)
    {
      filename[2] = j;
      if (unlink(filename) < 0 )
      {
        printf("remove file failed\n");
        exit(1);
      }
    }
  }
  return;
}

int main()
{
  //创建测试用目录
  if (chdir("dirtest") < 0){
    if (mkdir("dirtest") < 0){
      printf("mkdir dirtest failed\n");
      exit(1);
    }
    if (chdir("dirtest") < 0)
    {
      printf("chdir dirtest failed\n");
      exit(1);
    }
  }
  else{
    printf("directory dirtest already existed\n");
  }
  // 测试 - 目录查找
  printf("directory lookup test starting\n");
  printf("creating 169 empty files\n");
  printf("create cost time : %d ticks\n", create_files());
  printf("ls running to list 169 files\n");
  printf("ls cost time : %d licks\n",ls_files());
  remove_files();
  // 返回原目录
  if (chdir("..") < 0)
  {
    printf("dirtest chdir failed\n");
    exit(1);
  }
  //删掉
  if (unlink("dirtest") < 0)
  {
    printf("remove testdir failed\n");
    exit(1);
  }
  exit(0);
}