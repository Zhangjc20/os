#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <assert.h>

#define stat xv6_stat  // avoid clash with host struct stat
#include "kernel/types.h"
#include "kernel/fs.h"
#include "kernel/stat.h"
#include "kernel/param.h"

#ifndef static_assert
#define static_assert(a, b) do { switch (0) case 0: case (a): ; } while (0)
#endif

#define NINODES 200

// Disk layout:
// [ boot block | sb block | log | inode blocks | free bit map | data blocks ]

int nbitmap = FSSIZE/(BSIZE*8) + 1;
int ninodeblocks = NINODES / IPB + 1;
int nlog = LOGSIZE;
int nmeta;    // Number of meta blocks (boot, sb, nlog, inode, bitmap)
int nblocks;  // Number of data blocks

int fsfd;
struct superblock sb;
char zeroes[BSIZE];
uint freeinode = 1;
uint freeblock;

void diradd(uint, struct dirent*);
void balloc(int);
void wsect(uint, void*);
void winode(uint, struct dinode*);
void rinode(uint inum, struct dinode *ip);
void rsect(uint sec, void *buf);
uint ialloc(ushort type);
void iappend(uint inum, void *p, int n);
void die(const char *);

#define min(a, b) ((a) < (b) ? (a) : (b))

uint gethash
(const char *name, int isdirect)
{
  uint bucket_num;
  if (isdirect == 1){
    bucket_num = N_INDIRECT_HASH_BUCKET;
  }
  else if (isdirect == 0){
    bucket_num = N_DIRECT_HASH_BUCKET;
  }
  else{
    bucket_num = N_ININDIRECT_HASH_BUCKET;
  }
  uint hashkey = 0;
  for (int i = 0; i < DIRSIZ; i++)
  {
    if (name[i] == 0)
      break;
    hashkey = (hashkey + ((uchar)(name[i]) - '0') * (i + 1) % bucket_num) % bucket_num;
  }
  return hashkey;
}

// convert to intel byte order
ushort
xshort(ushort x)
{
  ushort y;
  uchar *a = (uchar*)&y;
  a[0] = x;
  a[1] = x >> 8;
  return y;
}

uint
xint(uint x)
{
  uint y;
  uchar *a = (uchar*)&y;
  a[0] = x;
  a[1] = x >> 8;
  a[2] = x >> 16;
  a[3] = x >> 24;
  return y;
}

int
main(int argc, char *argv[])
{
  int i, cc, fd;
  uint rootino, inum; //off
  struct dirent de;
  char buf[BSIZE];
  // struct dinode din;


  static_assert(sizeof(int) == 4, "Integers must be 4 bytes!");

  if(argc < 2){
    fprintf(stderr, "Usage: mkfs fs.img files...\n");
    exit(1);
  }

  assert((BSIZE % sizeof(struct dinode)) == 0);
  assert((BSIZE % sizeof(struct dirent)) == 0);

  fsfd = open(argv[1], O_RDWR|O_CREAT|O_TRUNC, 0666);
  if(fsfd < 0)
    die(argv[1]);

  // 1 fs block = 1 disk sector
  nmeta = 2 + nlog + ninodeblocks + nbitmap;
  nblocks = FSSIZE - nmeta;

  sb.magic = FSMAGIC;
  sb.size = xint(FSSIZE);
  sb.nblocks = xint(nblocks);
  sb.ninodes = xint(NINODES);
  sb.nlog = xint(nlog);
  sb.logstart = xint(2);
  sb.inodestart = xint(2+nlog);
  sb.bmapstart = xint(2+nlog+ninodeblocks);

  printf("nmeta %d (boot, super, log blocks %u inode blocks %u, bitmap blocks %u) blocks %d total %d\n",
         nmeta, nlog, ninodeblocks, nbitmap, nblocks, FSSIZE);

  freeblock = nmeta;     // the first free block that we can allocate

  for(i = 0; i < FSSIZE; i++)
    wsect(i, zeroes);

  memset(buf, 0, sizeof(buf));
  memmove(buf, &sb, sizeof(sb));
  wsect(1, buf);

  rootino = ialloc(T_DIR);
  assert(rootino == ROOTINO);

  bzero(&de, sizeof(de));
  de.inum = xshort(rootino);
  strcpy(de.name, ".");
  iappend(rootino, &de, sizeof(de));

  bzero(&de, sizeof(de));
  de.inum = xshort(rootino);
  strcpy(de.name, "..");
  iappend(rootino, &de, sizeof(de));

  for(i = 2; i < argc; i++){
    // get rid of "user/"
    char *shortname;
    if(strncmp(argv[i], "user/", 5) == 0)
      shortname = argv[i] + 5;
    else
      shortname = argv[i];
    
    assert(index(shortname, '/') == 0);

    if((fd = open(argv[i], 0)) < 0)
      die(argv[i]);

    // Skip leading _ in name when writing to file system.
    // The binaries are named _rm, _cat, etc. to keep the
    // build operating system from trying to execute them
    // in place of system binaries like rm and cat.
    if(shortname[0] == '_')
      shortname += 1;

    inum = ialloc(T_FILE);

    bzero(&de, sizeof(de));
    de.inum = xshort(inum);
    strncpy(de.name, shortname, DIRSIZ);
    diradd(rootino, &de);

    while((cc = read(fd, buf, sizeof(buf))) > 0)
      iappend(inum, buf, cc);

    close(fd);
  }

  balloc(freeblock);

  exit(0);
}

void
wsect(uint sec, void *buf)
{
  if(lseek(fsfd, sec * BSIZE, 0) != sec * BSIZE)
    die("lseek");
  if(write(fsfd, buf, BSIZE) != BSIZE)
    die("write");
}

void
winode(uint inum, struct dinode *ip)
{
  char buf[BSIZE];
  uint bn;
  struct dinode *dip;

  bn = IBLOCK(inum, sb);
  rsect(bn, buf);
  dip = ((struct dinode*)buf) + (inum % IPB);
  *dip = *ip;
  wsect(bn, buf);
}

void
rinode(uint inum, struct dinode *ip)
{
  char buf[BSIZE];
  uint bn;
  struct dinode *dip;

  bn = IBLOCK(inum, sb);
  rsect(bn, buf);
  dip = ((struct dinode*)buf) + (inum % IPB);
  *ip = *dip;
}

void
rsect(uint sec, void *buf)
{
  if(lseek(fsfd, sec * BSIZE, 0) != sec * BSIZE)
    die("lseek");
  if(read(fsfd, buf, BSIZE) != BSIZE)
    die("read");
}

uint
ialloc(ushort type)
{
  uint inum = freeinode++;
  struct dinode din;

  bzero(&din, sizeof(din));
  din.type = xshort(type);
  din.nlink = xshort(1);
  din.size = xint(0);
  winode(inum, &din);
  return inum;
}

void
balloc(int used)
{
  uchar buf[BSIZE];
  int i;

  printf("balloc: first %d blocks have been allocated\n", used);
  assert(used < BSIZE*8);
  bzero(buf, BSIZE);
  for(i = 0; i < used; i++){
    buf[i/8] = buf[i/8] | (0x1 << (i%8));
  }
  printf("balloc: write bitmap block at sector %d\n", sb.bmapstart);
  wsect(sb.bmapstart, buf);
}

#define min(a, b) ((a) < (b) ? (a) : (b))

void
iappend(uint inum, void *xp, int n)
{
  char *p = (char*)xp;
  uint fbn, off, n1;
  struct dinode din;
  char buf[BSIZE];
  uint indirect[NINDIRECT];
  uint x;

  rinode(inum, &din);
  off = xint(din.size);
  while(n > 0){
    fbn = off / BSIZE;
    assert(fbn < MAXFILE);
    if(fbn < NDIRECT){
      if(xint(din.addrs[fbn]) == 0){
        din.addrs[fbn] = xint(freeblock++);
      }
      x = xint(din.addrs[fbn]);
    } else {
      if(xint(din.addrs[NDIRECT]) == 0){
        din.addrs[NDIRECT] = xint(freeblock++);
      }
      rsect(xint(din.addrs[NDIRECT]), (char*)indirect);
      if(indirect[fbn - NDIRECT] == 0){
        indirect[fbn - NDIRECT] = xint(freeblock++);
        wsect(xint(din.addrs[NDIRECT]), (char*)indirect);
      }
      x = xint(indirect[fbn-NDIRECT]);
    }
    n1 = min(n, (fbn + 1) * BSIZE - off);
    rsect(x, buf);
    bcopy(p, buf + off - (fbn * BSIZE), n1);
    wsect(x, buf);
    n -= n1;
    off += n1;
    p += n1;
  }
  din.size = xint(off);
  winode(inum, &din);
}

#define max(a, b) ((a) > (b) ? (a) : (b))
uint diralloc//返回off所在块的地址
(struct dinode *dp, uint off)// 为inode dp分配块，置off所在block及之前所有块非空
{
  uint cur_block = off / BSIZE + 1, i, addr, block_addr, indirect[NINDIRECT];
  for (i = 0; i < min(cur_block, NDIRECT); ++i){
    if (dp->addrs[i] == 0){
      dp->addrs[i] = xint(freeblock);
      freeblock++;
    }
  }
  if (cur_block <= NDIRECT){
    block_addr = xint(dp->addrs[cur_block - 1]);
  }
  else if (cur_block - NDIRECT <= NINDIRECT){
    uint indirect_blockn = cur_block - NDIRECT;
    if ((addr = dp->addrs[NDIRECT]) == 0){
      dp->addrs[NDIRECT] = addr = xint(freeblock);
      freeblock++;
    }
    rsect(xint(addr), (char *)indirect);
    for (i = 0; i < indirect_blockn; ++i){
      if (indirect[i] == 0){
        indirect[i] = xint(freeblock);
        freeblock++;
        wsect(xint(addr), (char *)indirect);
      }
    }
    block_addr = xint(indirect[indirect_blockn - 1]);
  }
  else{
    return 0;
  }
  dp->size = max(cur_block * BSIZE , dp->size);
  return block_addr;
}

void diradd
(uint inum, struct dirent *de)// 在目录inode(inum 由确定)中增加目录de
{
  struct dinode dino;
  uint loff = 0, roff = MAXOFF, toff = 0, hash = 0, addr = 0, isdirect = 1, isindirect = 0, isinindirect = 0;
  char buf[BSIZE];
  rinode(inum, &dino);
  while (loff < MAXFSIZE)
  {
    if (loff == 0 && isdirect == 1){//直接块
      hash = gethash(de->name, 0);
      loff = DIRECT_BUCKET_OFF(hash);
      roff = DIRECT_BUCKET_OFF(hash + 1);
    }
    else if (loff < INDIRECT_BUCKET_OFF(hash + 1) && isdirect == 0 && isindirect == 1){//间接块
      hash = gethash(de->name, 1);
      loff = INDIRECT_BUCKET_OFF(hash);
      roff = INDIRECT_BUCKET_OFF(hash + 1);
    }
    else if (loff < ININDIRECT_BUCKET_OFF(hash + 1) && isindirect == 0 && isinindirect == 1){//溢出区
      hash = gethash(de->name, 2);
      loff = ININDIRECT_BUCKET_OFF(hash);
      roff = ININDIRECT_BUCKET_OFF(hash + 1);
    }
    for (toff = loff; toff < roff; toff += sizeof(struct dirent))
    {
      if ((addr = diralloc(&dino, toff)) == 0){
        printf("diralloc failed");
        return;
      }
      rsect(addr, buf);
      struct dirent *orig = (struct dirent *)(buf + (toff % BSIZE));
      if (orig->inum == 0)
      {
        bcopy(de, buf + (toff % BSIZE), sizeof(struct dirent));
        wsect(addr, buf);
        winode(inum, &dino);
        if ( toff % 16 != 0)
        {
          printf("toff : %d\n",toff);
        }
        assert(toff % 16 == 0);
        return;
      }
    }
    if(isdirect == 1){
      isdirect = 0;
      isindirect = 1;
    }
    if(isindirect == 1){
      isindirect = 0;
      isinindirect = 1;
    }
    if(isinindirect == 1){
      return;
    }
  }
}

void
die(const char *s)
{
  perror(s);
  exit(1);
}
