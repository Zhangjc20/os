//
// File-system system calls.
// Mostly argument checking, since we don't trust
// user code, and calls into file.c and fs.c.
//

#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "stat.h"
#include "spinlock.h"
#include "proc.h"
#include "fs.h"
#include "sleeplock.h"
#include "file.h"
#include "fcntl.h"

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
  int fd;
  struct file *f;

  if(argint(n, &fd) < 0)
    return -1;
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    return -1;
  if(pfd)
    *pfd = fd;
  if(pf)
    *pf = f;
  return 0;
}

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
  int fd;
  struct proc *p = myproc();

  for(fd = 0; fd < NOFILE; fd++){
    if(p->ofile[fd] == 0){
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
}

uint64
sys_dup(void)
{
  struct file *f;
  int fd;

  if(argfd(0, 0, &f) < 0)
    return -1;
  if((fd=fdalloc(f)) < 0)
    return -1;
  filedup(f);
  return fd;
}

uint64
sys_read(void)
{
  struct file *f;
  int n;
  uint64 p;

  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argaddr(1, &p) < 0)
    return -1;
  return fileread(f, p, n);
}

uint64
sys_write(void)
{
  struct file *f;
  int n;
  uint64 p;

  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argaddr(1, &p) < 0)
    return -1;

  return filewrite(f, p, n);
}

uint64
sys_close(void)
{
  int fd;
  struct file *f;

  if(argfd(0, &fd, &f) < 0)
    return -1;
  myproc()->ofile[fd] = 0;
  fileclose(f);
  return 0;
}

uint64
sys_fstat(void)
{
  struct file *f;
  uint64 st; // user pointer to struct stat

  if(argfd(0, 0, &f) < 0 || argaddr(1, &st) < 0)
    return -1;
  return filestat(f, st);
}

// Create the path new as a link to the same inode as old.
uint64
sys_link(void)
{
  char name[DIRSIZ], new[MAXPATH], old[MAXPATH];
  struct inode *dp, *ip;

  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    return -1;

  begin_op();
  if((ip = namei(old)) == 0){
    end_op();
    return -1;
  }

  ilock(ip);
  if(ip->type == T_DIR){
    iunlockput(ip);
    end_op();
    return -1;
  }

  ip->nlink++;
  lzrni_list_delete(ip->inum);
  iupdate(ip);
  iunlock(ip);

  if((dp = nameiparent(new, name)) == 0)
    goto bad;
  ilock(dp);
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    iunlockput(dp);
    goto bad;
  }
  iunlockput(dp);
  iput(ip);

  end_op();

  return 0;

bad:
  ilock(ip);
  ip->nlink--;
  if (ip->nlink == 0 && ip->ref > 0) {/*����superblock�б�*/
    lzrni_list_expand(ip->inum);
  }
  iupdate(ip);
  iunlockput(ip);
  end_op();
  return -1;
}

// Is the directory dp empty except for "." and ".." ?
static int
isdirempty(struct inode *dp)
{
  int off;
  struct dirent de;

  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
      panic("isdirempty: readi");
    if(de.inum != 0)
      return 0;
  }
  return 1;
}

uint64
sys_unlink(void)
{
  struct inode *ip, *dp;
  struct dirent de;
  char name[DIRSIZ], path[MAXPATH];
  uint off;

  if(argstr(0, path, MAXPATH) < 0)
    return -1;

  begin_op();
  if((dp = nameiparent(path, name)) == 0){
    end_op();
    return -1;
  }

  ilock(dp);

  // Cannot unlink "." or "..".
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    goto bad;

  if((ip = dirlookup(dp, name, &off)) == 0)
    goto bad;
  ilock(ip);

  if(ip->nlink < 1)
    panic("unlink: nlink < 1");
  if(ip->type == T_DIR && !isdirempty(ip)){
    int offf;
    uint temp_off;
    struct dirent dee;
    struct inode* ipp;

    for (offf = 2 * sizeof(dee); offf < ip->size; offf += sizeof(dee)) {
      if (readi(ip, 0, (uint64)&dee, offf, sizeof(dee)) != sizeof(dee))
        panic("unlink: readi");
      if (dee.inum == 0)
        continue;
      if ((ipp = dirlookup(ip, dee.name, &temp_off)) == 0) 
        panic("unlink:dirlookup");
      if (file_unlink(ip, ipp, temp_off) < 0)
        panic("unlink:file_unlink");
    }
    //iunlockput(ip);
    //goto bad;
  }

  memset(&de, 0, sizeof(de));
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    panic("unlink: writei");
  if(ip->type == T_DIR){
    dp->nlink--;
    if (dp->nlink == 0 && dp->ref > 0) {/*����superblock�б�*/
      lzrni_list_expand(dp->inum);
    }
    iupdate(dp);
  }
  iunlockput(dp);

  ip->nlink--;
  if (ip->nlink == 0 && ip->ref > 0) {/*����superblock�б�*/
    lzrni_list_expand(ip->inum);
  }
  iupdate(ip);
  iunlockput(ip);

  end_op();

  return 0;

bad:
  iunlockput(dp);
  end_op();
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    return 0;

  ilock(dp);

  if((ip = dirlookup(dp, name, 0)) != 0){//没有重名文件
    iunlockput(dp);
    ilock(ip);
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
      return ip;
    iunlockput(ip);
    return 0;
  }

  if((ip = ialloc(dp->dev, type)) == 0)
    panic("create: ialloc");

  ilock(ip);
  ip->major = major;
  ip->minor = minor;
  ip->nlink = 1;
  lzrni_list_delete(ip->inum);
  iupdate(ip);

  if(type == T_DIR){  // Create . and .. entries.
    dp->nlink++;  // for ".."
    lzrni_list_delete(dp->inum);
    iupdate(dp);
    // No ip->nlink++ for ".": avoid cyclic ref count.
    ip->size = sizeof(struct dirent) << 1;// Ϊ�µ�Ŀ¼���� . �� ..
    iupdate(ip);
    struct dirent de;
    for (uint off = 0; off <= sizeof(de); off += sizeof(de)){
      if (readi(ip, 0, (uint64)&de, off, sizeof(struct dirent)) != sizeof(struct dirent)){
        panic("dirinit read failed\n");
      }
      strncpy(de.name, off == 0 ? "." : "..", DIRSIZ);
      de.inum = off == 0 ? ip->inum : dp->inum;
      if (writei(ip, 0, (uint64)&de, off, sizeof(de)) != sizeof(de)){
        panic("dirinit write failed\n");
      }
    }
  }


  if(dirlink(dp, name, ip->inum) < 0)
    panic("create: dirlink");

  iunlockput(dp);

  return ip;
}

static struct inode*
create2(char *path, short type, short major, short minor)
{
  struct inode *ip, *dp;
  int t;
  t = strlen(path);
  char name[t];

  if((dp = nameiparent2(path, name)) == 0)
    return 0;
  ilock(dp);

  if((ip = dirlookup2(dp, name, 0)) != 0)
  {
   // printf("c\n");
    iunlockput(dp);
    ilock(ip);
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
      return ip;
    iunlockput(ip);
    return 0;
  }
 // printf("b\n");
  if((ip = ialloc(dp->dev, type)) == 0)/*����*/
    panic("create: ialloc");
  /*���ֲ����ڣ��·���һ��inode*/
  ilock(ip);
  ip->major = major;
  ip->minor = minor;
  ip->nlink = 1;
  iupdate(ip);

  if(type == T_DIR)
  {  // Create . and .. entries./*����µ�Ŀ¼��inode*/
    dp->nlink++;  // for ".."
    iupdate(dp);
    // No ip->nlink++ for ".": avoid cyclic ref count.
   // printf("x\n");
    if(dirlink2(ip, ".", ip->inum) < 0 || dirlink2(ip, "..", dp->inum) < 0)/*���ӵ���Ŀ¼��*/
      panic("create dots");
  }
  //printf("c");

  if(dirlink2(dp, name, ip->inum) < 0)
    panic("create: dirlink");

  iunlockput(dp);

  return ip;
}


uint64
sys_open(void)
{
  char path[MAXPATH];
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  if((n = argstr(0, path, MAXPATH)) < 0 || argint(1, &omode) < 0)
    return -1;

  begin_op();

  if(omode & O_CREATE){
    ip = create(path, T_FILE, 0, 0);
    if(ip == 0){
      end_op();
      return -1;
    }
  } else {
    if((ip = namei(path)) == 0){
      end_op();
      return -1;
    }
    ilock(ip);
    if(ip->type == T_DIR && omode != O_RDONLY){
      iunlockput(ip);
      end_op();
      return -1;
    }
  }

  // resolve symlink
  if(ip->type == T_SYMLINK){
    if(!(omode & O_NOFOLLOW)){
      int cycle = 0;
      char target[MAXPATH];
      while(ip->type == T_SYMLINK){
        if(cycle == 10){//防止无限套娃
          iunlockput(ip);
          end_op();
          return -1; // max cycle
        }
        cycle++;
        memset(target, 0, sizeof(target));
        readi(ip, 0, (uint64)target, 0, MAXPATH);//读储存的实际路径
        iunlockput(ip);
        if((ip = namei(target)) == 0){
          end_op();
          return -1; // target not exist
        }
        ilock(ip);
      }
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    if(f)
      fileclose(f);
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    f->off = 0;
  }
  f->ip = ip;
  f->readable = !(omode & O_WRONLY);
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);

  if((omode & O_TRUNC) && ip->type == T_FILE){
    itrunc(ip);
  }

  iunlock(ip);
  end_op();

  return fd;
}

uint64
sys_mkdir(void)
{
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    end_op();
    return -1;
  }
  iunlockput(ip);
  end_op();
  return 0;
}


uint64
sys_lgmk(void)
{
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
  if(argstr(0, path, MAXPATH) < 0 || (ip = create2(path, T_DIR, 0, 0)) == 0)
  {
    end_op();
    return -1;
  }
  iunlockput(ip);
  end_op();
  return 0;
}

uint64
sys_mknod(void)
{
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
  if((argstr(0, path, MAXPATH)) < 0 ||
     argint(1, &major) < 0 ||
     argint(2, &minor) < 0 ||
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    end_op();
    return -1;
  }
  iunlockput(ip);
  end_op();
  return 0;
}

uint64
sys_chdir(void)
{
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
  
  begin_op();
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    end_op();
    return -1;
  }
  ilock(ip);
  if(ip->type == T_DIR){
    iunlock(ip);
    iput(p->cwd);
    end_op();
    p->cwd = ip;
    return 0;
  }
  else if(ip->type == T_SYMLINK){
    char target[MAXPATH];
    struct inode *dp;
    memset(target, 0, sizeof(target));
    readi(ip, 0, (uint64)target, 0, MAXPATH);
    iunlockput(ip);
    if((dp = namei(target)) == 0){
      end_op();
      return -1; // target not exist
    }
    ilock(dp);
    if(dp->type != T_DIR){
      iunlockput(dp);
      end_op();
      return -1;
    }
    iunlock(dp);
    iput(p->cwd);
    end_op();
    p->cwd = dp;
    return 0;
  }
  iunlockput(ip);
  end_op();
  return -1;
}

uint64
sys_exec(void)
{
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  if(argstr(0, path, MAXPATH) < 0 || argaddr(1, &uargv) < 0){
    return -1;
  }
  memset(argv, 0, sizeof(argv));
  for(i=0;; i++){
    if(i >= NELEM(argv)){
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
      goto bad;
    }
    if(uarg == 0){
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
      goto bad;
  }

  int ret = exec(path, argv);

  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    kfree(argv[i]);
  return -1;
}

uint64
sys_pipe(void)
{
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();

  if(argaddr(0, &fdarray) < 0)
    return -1;
  if(pipealloc(&rf, &wf) < 0)
    return -1;
  fd0 = -1;
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    if(fd0 >= 0)
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    p->ofile[fd0] = 0;
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
}

uint64
sys_copy(void) {
  char path[MAXPATH], name[DIRSIZ];
  struct inode* ip;//���������ļ�inode
  struct inode* dp;//��ǰ����Ŀ¼
  uint off;

  begin_op();
  if (argstr(0, path, MAXPATH) < 0) {
    end_op();
    return -1;
  }
  //printf("%s\n", path);
  //printf("this is a copy!\n");
  //dp = idup(myproc()->cwd);
  if ((dp = nameiparent(path, name)) == 0) {
    end_op();
    return -1;
  }
  ilock(dp);
  if ((ip = dirlookup(dp, name, &off)) == 0) {
    iunlock(dp);
    end_op();
    return -1;
  }
  ilock(ip);
  write_cb(dp, ip, COPY, name, off);
  iunlockput(dp);
  iunlockput(ip);
  end_op();
  return 0;
}

uint64
sys_cut(void) {//改了这个！！！！！！！！！！！！！！！！！！！！！！！！！！！
  //printf("this is a cut!\n");
  char path[MAXPATH], name[DIRSIZ];
  struct inode* ip;//解析到的文件inode
  struct inode* dp;//当前工作目录
  uint off;

  begin_op();
  if (argstr(0, path, MAXPATH) < 0) {
    end_op();
    return -1;
  }
  //printf("%s\n", path);
  //dp = idup(myproc()->cwd);
  if ((dp = nameiparent(path, name)) == 0) {
    end_op();
    return -1;
  }
  ilock(dp);
  if ((ip = dirlookup(dp, name, &off)) == 0) {
    iunlock(dp);
    end_op();
    return -1;
  }
  ilock(ip);
  //printf("%d %s\n",dp->inum, name);
  if (dp->inum == ROOTINO && namecmp(name, "bin") == 0) {
    iunlock(dp);
    iunlock(ip);
    end_op();
    return -1;
  }
  write_cb(dp, ip, CUT, name, off);
  iunlockput(dp);
  iunlockput(ip);
  end_op();
  return 0;
}

uint64
sys_paste(void) {
  //printf("this is a paste!\n");
  begin_op();
  if (clean_cb() < 0) {
    end_op();
    return -1;
  }
  //printf("1");
  end_op();
  return 0;
}

uint64
sys_symlink(void) {
  char old[MAXPATH], new[MAXPATH];
  struct inode *ip;

  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0){
    return -1;
  }

  begin_op();
  if((ip = create(new, T_SYMLINK, 0, 0)) == 0){
    end_op();
    return -1;
  }

  if(writei(ip, 0, (uint64)old, 0, MAXPATH) != MAXPATH){
    panic("symlink write failed");
    return -1;
  }

  iunlockput(ip);
  end_op();
  return 0;
}
