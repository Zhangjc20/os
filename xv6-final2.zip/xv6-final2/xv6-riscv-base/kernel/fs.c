// File system implementation.  Five layers:
//   + Blocks: allocator for raw disk blocks.
//   + Log: crash recovery for multi-step updates.
//   + Files: inode allocator, reading, writing, metadata.
//   + Directories: inode with special contents (list of other inodes!)
//   + Names: paths like /usr/rtm/xv6/fs.c for convenient naming.
//
// This file contains the low-level file system manipulation
// routines.  The (higher-level) system call implementations
// are in sysfile.c.

#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "stat.h"
#include "spinlock.h"
#include "proc.h"
#include "sleeplock.h"
#include "fs.h"
#include "buf.h"
#include "file.h"

#define min(a, b) ((a) < (b) ? (a) : (b))
// there should be one superblock per disk device, but we run with
// only one device
struct superblock sb; 

/*clipboard definition*/
struct clipboard {
  struct inode* dir_parent_inode;
  struct inode* dir_inode;
  uint off;
  int state;//UNUSED,COPY,CUT
  char fname[DIRSIZ];
}cb;

// Read the super block.
static void
readsb(int dev, struct superblock *sb)
{
  struct buf *bp;

  bp = bread(dev, 1);
  memmove(sb, bp->data, sizeof(*sb));
  brelse(bp);
}

void print_superblock_list() {
  for (int i = 0; i < sb.lzrni_list_num; i++) {
    printf("%d-", sb.link_zero_ref_nonzero_inode_list[i]);
  }
  printf("\n");
}

// Init fs
void
fsinit(int dev) {
  readsb(dev, &sb);
  init_cb();
  if(sb.magic != FSMAGIC)
    panic("invalid file system");
  initlog(dev, &sb);
}

// Zero a block.
static void
bzero(int dev, int bno)
{
  struct buf *bp;

  bp = bread(dev, bno);
  memset(bp->data, 0, BSIZE);
  log_write(bp);
  brelse(bp);
}

// Blocks.

// Allocate a zeroed disk block.
static uint
balloc(uint dev)
{
  int b, bi, m;
  struct buf *bp;

  bp = 0;
  for(b = 0; b < sb.size; b += BPB){
    bp = bread(dev, BBLOCK(b, sb));
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
      m = 1 << (bi % 8);
      if((bp->data[bi/8] & m) == 0){  // Is block free?
        bp->data[bi/8] |= m;  // Mark block in use.
        log_write(bp);
        brelse(bp);
        bzero(dev, b + bi);
        return b + bi;
      }
    }
    brelse(bp);
  }
  panic("balloc: out of blocks");
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
  bi = b % BPB;
  m = 1 << (bi % 8);
  if((bp->data[bi/8] & m) == 0)
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
  log_write(bp);
  brelse(bp);
}

// Inodes.
//
// An inode describes a single unnamed file.
// The inode disk structure holds metadata: the file's type,
// its size, the number of links referring to it, and the
// list of blocks holding the file's content.
//
// The inodes are laid out sequentially on disk at
// sb.startinode. Each inode has a number, indicating its
// position on the disk.
//
// The kernel keeps a table of in-use inodes in memory
// to provide a place for synchronizing access
// to inodes used by multiple processes. The in-memory
// inodes include book-keeping information that is
// not stored on disk: ip->ref and ip->valid.
//
// An inode and its in-memory representation go through a
// sequence of states before they can be used by the
// rest of the file system code.
//
// * Allocation: an inode is allocated if its type (on disk)
//   is non-zero. ialloc() allocates, and iput() frees if
//   the reference and link counts have fallen to zero.
//
// * Referencing in table: an entry in the inode table
//   is free if ip->ref is zero. Otherwise ip->ref tracks
//   the number of in-memory pointers to the entry (open
//   files and current directories). iget() finds or
//   creates a table entry and increments its ref; iput()
//   decrements ref.
//
// * Valid: the information (type, size, &c) in an inode
//   table entry is only correct when ip->valid is 1.
//   ilock() reads the inode from
//   the disk and sets ip->valid, while iput() clears
//   ip->valid if ip->ref has fallen to zero.
//
// * Locked: file system code may only examine and modify
//   the information in an inode and its content if it
//   has first locked the inode.
//
// Thus a typical sequence is:
//   ip = iget(dev, inum)
//   ilock(ip)
//   ... examine and modify ip->xxx ...
//   iunlock(ip)
//   iput(ip)
//
// ilock() is separate from iget() so that system calls can
// get a long-term reference to an inode (as for an open file)
// and only lock it for short periods (e.g., in read()).
// The separation also helps avoid deadlock and races during
// pathname lookup. iget() increments ip->ref so that the inode
// stays in the table and pointers to it remain valid.
//
// Many internal file system functions expect the caller to
// have locked the inodes involved; this lets callers create
// multi-step atomic operations.
//
// The itable.lock spin-lock protects the allocation of itable
// entries. Since ip->ref indicates whether an entry is free,
// and ip->dev and ip->inum indicate which i-node an entry
// holds, one must hold itable.lock while using any of those fields.
//
// An ip->lock sleep-lock protects all ip-> fields other than ref,
// dev, and inum.  One must hold ip->lock in order to
// read or write that inode's ip->valid, ip->size, ip->type, &c.

struct {
  struct spinlock lock;
  struct inode inode[NINODE];
} itable;

void
iinit()
{
  int i = 0;
  
  initlock(&itable.lock, "itable");
  for(i = 0; i < NINODE; i++) {
    initsleeplock(&itable.inode[i].lock, "inode");
  }
}

static struct inode* iget(uint dev, uint inum);

// Allocate an inode on device dev.
// Mark it as allocated by  giving it type type.
// Returns an unlocked but allocated and referenced inode.
struct inode*
ialloc(uint dev, short type)
{
  int inum;
  struct buf *bp;
  struct dinode *dip;

  for(inum = 1; inum < sb.ninodes; inum++){
    bp = bread(dev, IBLOCK(inum, sb));
    dip = (struct dinode*)bp->data + inum%IPB;
    if(dip->type == 0){  // a free inode
      memset(dip, 0, sizeof(*dip));
      dip->type = type;
      log_write(bp);   // mark it allocated on the disk
      brelse(bp);
      return iget(dev, inum);
    }
    brelse(bp);
  }
  panic("ialloc: no inodes");
}

// Copy a modified in-memory inode to disk.
// Must be called after every change to an ip->xxx field
// that lives on disk.
// Caller must hold ip->lock.
void
iupdate(struct inode *ip)
{
  struct buf *bp;
  struct dinode *dip;

  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
  dip = (struct dinode*)bp->data + ip->inum%IPB;
  dip->type = ip->type;
  dip->major = ip->major;
  dip->minor = ip->minor;
  dip->nlink = ip->nlink;
  dip->size = ip->size;
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
  log_write(bp);
  brelse(bp);
}

// Find the inode with number inum on device dev
// and return the in-memory copy. Does not lock
// the inode and does not read it from disk.
static struct inode*
iget(uint dev, uint inum)
{
  struct inode *ip, *empty;

  acquire(&itable.lock);

  // Is the inode already in the table?
  empty = 0;
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
      ip->ref++;
      release(&itable.lock);
      return ip;
    }
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
      empty = ip;
  }

  // Recycle an inode entry.
  if(empty == 0)
    panic("iget: no inodes");

  ip = empty;
  ip->dev = dev;
  ip->inum = inum;
  ip->ref = 1;
  ip->valid = 0;
  release(&itable.lock);

  return ip;
}

// Increment reference count for ip.
// Returns ip to enable ip = idup(ip1) idiom.
struct inode*
idup(struct inode *ip)
{
  acquire(&itable.lock);
  ip->ref++;
  release(&itable.lock);
  return ip;
}

// Lock the given inode.
// Reads the inode from disk if necessary.
void
ilock(struct inode *ip)
{
  struct buf *bp;
  struct dinode *dip;

  if(ip == 0 || ip->ref < 1)
    panic("ilock");

  acquiresleep(&ip->lock);

  if(ip->valid == 0){
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    ip->type = dip->type;
    ip->major = dip->major;
    ip->minor = dip->minor;
    ip->nlink = dip->nlink;
    ip->size = dip->size;
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    brelse(bp);
    ip->valid = 1;
    if(ip->type == 0)
      panic("ilock: no type");
  }
}

// Unlock the given inode.
void
iunlock(struct inode *ip)
{
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    panic("iunlock");

  releasesleep(&ip->lock);
}

// Drop a reference to an in-memory inode.
// If that was the last reference, the inode table entry can
// be recycled.
// If that was the last reference and the inode has no links
// to it, free the inode (and its content) on disk.
// All calls to iput() must be inside a transaction in
// case it has to free the inode.
void
iput(struct inode *ip)
{
  acquire(&itable.lock);

  if (ip->ref == 1 && ip->valid && ip->nlink == 0) {
    /*�ݼ�ref��û��ָ��ָ���inode������û���κ�Ŀ¼�����Ӹ�inode�����inode���������ݿ���뱻�ͷ�*/
    /*�ݼ����������Ϊ0��inode���潫�ͷŵ���inode��inode�����еĲ�λ���ò�λ�Ϳ��Ա�����inodeʹ�á�*/
    // inode has no links and no other references: truncate and free.

    // ip->ref == 1 means no other process can have ip locked,
    // so this acquiresleep() won't block (or deadlock).
    acquiresleep(&ip->lock);/*������inode*/

    release(&itable.lock);

    /*����superlock�е��б�*/
    if (sb.lzrni_list_num > NINODE) {/*���ϼ��*/
      panic("lzrni list overflows");
    }

    int i, flag = 0;
    uint tem;

    for (i = 0; i < sb.lzrni_list_num; i++) {
      if (sb.link_zero_ref_nonzero_inode_list[i] == ip->inum) {
        /*���ҵ���inum���б����һ��Ԫ�ؽ���λ��*/
        tem = sb.link_zero_ref_nonzero_inode_list[sb.lzrni_list_num - 1];
        sb.link_zero_ref_nonzero_inode_list[sb.lzrni_list_num - 1] = sb.link_zero_ref_nonzero_inode_list[i];
        sb.link_zero_ref_nonzero_inode_list[i] = tem;
        /*�ݼ��б�Ԫ�ظ���*/
        sb.lzrni_list_num--;
        /*�˳�ѭ��*/
        flag = 1;
        break;
      }
    }

    if (i == sb.lzrni_list_num && !flag) {/*���ϼ��*/
      panic("can't find expected inode in lzrni_list");
    }

    //print_superblock_list();/*��ʾЧ��*/

    itrunc(ip);/*���ļ��ض�Ϊ0�ֽڣ��ͷ����ݿ�*/
    ip->type = 0;/*����Ϊδ����*/
    iupdate(ip);/*����inodeд�����*/
    ip->valid = 0;/*����Ϊδ�Ӵ����Ͽ�����Ӧ��Ϣ*/

    releasesleep(&ip->lock);/*�ͷ����inode��˯����*/

    acquire(&itable.lock);
  }

  ip->ref--;/*�ݼ����ô���*/
  release(&itable.lock);
}

// Common idiom: unlock, then put.
void
iunlockput(struct inode *ip)
{
  iunlock(ip);
  iput(ip);
}

void
violent_iput(uint inum_temp) {
  acquire(&itable.lock);

  /*����inum_temp������Ӧ��inode��ɾ��*/
  struct inode *ip;
  int flag = 0;
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    if (ip->inum == inum_temp) {
      flag = 1;
      break;
    }
  }

  if (!flag) {/*���ϼ��*/
    panic("lzrni list doesn't have expected inode in itable");
  }

  acquiresleep(&ip->lock);

  release(&itable.lock);

  itrunc(ip);/*���ļ��ض�Ϊ0�ֽ�*/
  ip->type = 0;/*����Ϊδ����*/
  iupdate(ip);
  ip->valid = 0;

  releasesleep(&ip->lock);

  acquire(&itable.lock);

  ip->ref = 0;/*���ô�����Ϊ0*/
  release(&itable.lock);
}

void
clean_lzrni_list() {
  for (int i = 0; i < sb.lzrni_list_num; i++) {
    violent_iput(sb.link_zero_ref_nonzero_inode_list[i]);
  }
  sb.lzrni_list_num = 0;/*���superblock�е��б�*/
}

int/*��Ȼû��bool����*/
inum_exist(uint inum_temp) {/*���������inode�Ƿ��Ѿ���superblock���б���*/
  for (int i = 0; i < sb.lzrni_list_num; i++) {
    if (sb.link_zero_ref_nonzero_inode_list[i] == inum_temp) {
      return 1;
    }
  }
  return 0;
}

void
lzrni_list_expand(uint inum_temp) {/*��superblock�б��м������������inum*/
  if (!inum_exist(inum_temp)) {
    if (sb.lzrni_list_num == NINODE) {/*���ϼ��*/
      panic("lzrni list overflow");
    }
    sb.link_zero_ref_nonzero_inode_list[sb.lzrni_list_num] = inum_temp;
    sb.lzrni_list_num++;

    //print_superblock_list();/*��ʾЧ��*/
  }
}

void 
lzrni_list_delete(uint inum_temp) {//nlink����ʱ���������б�
  if (inum_exist(inum_temp)) {

    for (int i = 0; i < sb.lzrni_list_num; i++) {
      if (sb.link_zero_ref_nonzero_inode_list[i] == inum_temp) {
        /*���ҵ���inum���б����һ��Ԫ�ؽ���λ��*/
        uint tem = sb.link_zero_ref_nonzero_inode_list[sb.lzrni_list_num - 1];
        sb.link_zero_ref_nonzero_inode_list[sb.lzrni_list_num - 1] = sb.link_zero_ref_nonzero_inode_list[i];
        sb.link_zero_ref_nonzero_inode_list[i] = tem;
        /*�ݼ��б�Ԫ�ظ���*/
        sb.lzrni_list_num--;
        /*�˳�ѭ��*/
        return;
      }
    }
  }
}

// Inode content
//
// The content (data) associated with each inode is stored
// in blocks on the disk. The first NDIRECT block numbers
// are listed in ip->addrs[].  The next NINDIRECT blocks are
// listed in block ip->addrs[NDIRECT].

// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
static uint
bmap(struct inode *ip, uint bn)
{
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    if((addr = ip->addrs[bn]) == 0)
      ip->addrs[bn] = addr = balloc(ip->dev);
    return addr;
  }
  bn -= NDIRECT;

  if(bn < NINDIRECT){
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0)
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
    bp = bread(ip->dev, addr);
    a = (uint*)bp->data;
    if((addr = a[bn]) == 0){
      a[bn] = addr = balloc(ip->dev);
      log_write(bp);
    }
    brelse(bp);
    return addr;
  }
  bn -= NINDIRECT;

  if(bn < NININDIRECT)
  {
    if((addr = ip->addrs[NDIRECT+1]) == 0)
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
    bp = bread(ip->dev, addr);
    a = (uint*)bp->data;
    uint b_1 = ( bn & 0xff00)>>8;
    uint b_2 = bn & 0xff;
    if((addr = a[b_1]) == 0)
    {
      a[b_1] = addr = balloc(ip->dev);
      log_write(bp);
    }
    brelse(bp);

    bp = bread(ip->dev, addr);
    a = (uint*)bp->data;
    if((addr = a[b_2])==0)
    {
      a[b_2] = addr =balloc(ip->dev);
      log_write(bp);
    }
    brelse(bp);

    return addr;
  }

  panic("bmap: out of range");
}

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    if(ip->addrs[i]){
      bfree(ip->dev, ip->addrs[i]);
      ip->addrs[i] = 0;
    }
  }

  if(ip->addrs[NDIRECT]){
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    a = (uint*)bp->data;
    for(j = 0; j < NINDIRECT; j++){
      if(a[j])
        bfree(ip->dev, a[j]);
    }
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  if(ip->addrs[NDIRECT+1])
  {
    bp = bread(ip->dev,ip->addrs[NDIRECT+1]);
    a = (uint*)bp->data;

    struct buf *bpd;
    uint* b;
    for (int j = 0;j < NINDIRECT;j++)
    {
      if(a[j])
      {
        bpd = bread(ip->dev, a[j]);
	b = (uint*)bpd->data;
	for (int k = 0; k < NINDIRECT; k++)
	{
	  if(b[k])
	    bfree(ip->dev, b[k]);
	}
	brelse(bpd);
	bfree(ip->dev,a[j]);
      }
    }
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT+1]);
    ip->addrs[NDIRECT + 1] = 0;
  }
  ip->size = 0;
  iupdate(ip);
}

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
  st->dev = ip->dev;
  st->ino = ip->inum;
  st->type = ip->type;
  st->nlink = ip->nlink;
  st->size = ip->size;
}

// Read data from inode.
// Caller must hold ip->lock.
// If user_dst==1, then dst is a user virtual address;
// otherwise, dst is a kernel address.
int
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    return 0;
  if(off + n > ip->size)
    n = ip->size - off;

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
    m = min(n - tot, BSIZE - off%BSIZE);
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
  }
  return tot;
}

// Write data to inode.
// Caller must hold ip->lock.
// If user_src==1, then src is a user virtual address;
// otherwise, src is a kernel address.
// Returns the number of bytes successfully written.
// If the return value is less than the requested n,
// there was an error of some kind.
int
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    return -1;
  if(off + n > MAXFILE*BSIZE)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
    m = min(n - tot, BSIZE - off%BSIZE);
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
      brelse(bp);
      break;
    }
    log_write(bp);
    brelse(bp);
  }

  if(off > ip->size)
    ip->size = off;

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);

  return tot;
}

uint dirballoc//���ط��������
(struct inode *ip, uint off)//Ϊinode dp����飬��off����block��֮ǰ���п�ǿ�
{
  uint block_num = off / BSIZE,fb = (ip->size / BSIZE) + (ip->size % BSIZE ? 1 : 0), addr, *a; // ��һ�������Ŀ��
  if (block_num < fb)
    return 0;
  uint b = fb;
  for (; b <= min(block_num, NDIRECT - 1); ++b){
    ip->addrs[b] = balloc(ip->dev);
  }
  if (block_num >= NDIRECT){//��ӿ�
    if ((addr = ip->addrs[NDIRECT]) == 0)
    {
      addr = balloc(ip->dev);
      ip->addrs[NDIRECT] = addr;
    }
    struct buf *bp = bread(ip->dev, addr);
    a = (uint *)bp->data;
    for (  ; b <= block_num; ++b)
    {
      a[b-NDIRECT] = balloc(ip->dev);
    }
    log_write( bp);
    brelse( bp);
  }
  return (block_num - fb + 1);
}

#define max(a, b) ((a) > (b) ? (a) : (b))
// ������Ӧȷ�� size �Ϸ�
uint largeni
(struct inode *ip, uint off){// �� inode �Ӵ�ָ�� offset
  uint end = off + 1, orig_b = max( ip->size - 1 , 0) / BSIZE;
  if ( dirballoc(ip, off) )
    end = (orig_b + 1) * BSIZE;

  // �� ip->size ~ inblk_size - 1 �� 0
  if (ip->size % BSIZE)
  {
    struct buf *bp = bread(ip->dev, bmap(ip, orig_b));
    memset(bp->data + (ip->size % BSIZE), 0, end - ip->size);
    log_write(bp);
    brelse(bp);
  }
  ip->size = off + 1;
  iupdate(ip);
  return off;
}

// Directories

uint gethash
(const char *name, int isdirect)
{
  uint bucket_num;
  if (isdirect == 1){//1代表在间接块中
    bucket_num = N_INDIRECT_HASH_BUCKET;
  }
  else if (isdirect == 0){//0代表在直接块中
    bucket_num = N_DIRECT_HASH_BUCKET;
  }
  else{//2代表在二次间接块中
    bucket_num = N_ININDIRECT_HASH_BUCKET;
  }
  uint hashkey = 0;
  for (int i = 0; i < DIRSIZ; i++)
  {
    if (name[i] == 0)
      break;//除留余数法求哈希值
    hashkey = (hashkey + ((uchar)(name[i]) - '0') * (i + 1) % bucket_num) % bucket_num;
  }
  return hashkey;
}

int
namecmp(const char *s, const char *t)
{
  return strncmp(s, t, DIRSIZ);
}

// 不能处理 . 和 ..
void dirfind
(struct dirent *de, struct inode *dp, char *name, int modifying, uint *poff,
             int (*query)(struct dirent *, char *))//遍历目录项，写入*de
{
  uint loff = 0, roff = MAXOFF, toff = 0, hash, isdirect = 1, isindirect = 0, isinindirect = 0;
  while (loff < MAXFSIZE){
    if (loff == 0 && isdirect == 1){//直接块
      hash = gethash(name, 0);
      loff = DIRECT_BUCKET_OFF(hash);
      roff = DIRECT_BUCKET_OFF(hash + 1);
    }
    else if (loff < INDIRECT_BUCKET_OFF(hash + 1) && isdirect == 0 && isindirect == 1){//间接块
      hash = gethash(name, 1);
      loff = INDIRECT_BUCKET_OFF(hash);
      roff = INDIRECT_BUCKET_OFF(hash + 1);
    }
    else if (loff < ININDIRECT_BUCKET_OFF(hash + 1) && isindirect == 0 && isinindirect == 1){//二次间接块
      hash = gethash(name, 2);
      loff = ININDIRECT_BUCKET_OFF(hash);
      roff = ININDIRECT_BUCKET_OFF(hash + 1);
    }
    for (toff = loff; toff < roff; toff += sizeof(struct dirent)){
      if (toff >= dp->size)
      {// modifying: 如果为 0，算出的 offset 比 size 大时直接退出,否则，会修改 size 使 bmap 分配块
        if (modifying){//为dp分配 block,off及之前置为非空
          largeni(dp, roff - 1);
        }
        else{
          de->inum = 0;
          return;
        }
      }
      if (readi(dp, 0, (uint64)de, toff, sizeof(struct dirent)) != sizeof(struct dirent)){
        panic("dirfind read failed");
      }
      if (query(de, name)){
        if (poff){
          *poff = toff;// 找到时会将 offset 写入 poff
        }
        return;
      }
    }
    if(isdirect == 1){
      isdirect = 0;
      isindirect = 1;
    }
    if(isindirect == 1){
      isindirect = 0;
      isinindirect = 1;
    }
    if(isinindirect == 1){
      de->inum = 0;
      return;
    }
  }
  de->inum = 0;// 若找不到，将 de-> inum 置 0
}

int dir_lookup(struct dirent *de, char *name)
{
  if (namecmp(de->name, name) == 0)
    return 1;
  return 0;
}

// ��Ҫȷ������������ . �� ..
// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode *
dirlookup(struct inode *dp, char *name, uint *poff)
{
  struct dirent de;
  if (namecmp(name, ".") == 0){//特别处理.和..
    if (readi(dp, 0, (uint64)&de, 0, sizeof(struct dirent)) != sizeof(struct dirent)){
      panic("dirlookup read failed");
    }
  }
  else if (namecmp(name, "..") == 0){
    if (readi(dp, 0, (uint64)&de, sizeof(struct dirent), sizeof(struct dirent)) != sizeof(struct dirent)){
      panic("dirlookup read failed");
    }
  }
  else{//除去特殊情况一般哈希寻找
    dirfind(&de, dp, name, 0, poff, dir_lookup);
  }
  if (de.inum){
    return iget(dp->dev, de.inum);
  }
  return 0;
}

struct inode*
dirlookup2(struct inode *dp, char *name, uint *poff)
{
  //int len = strlen(name);
  //printf("dirlook namelen = %d\n",len);//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  uint off, inum;
  struct dirent de;
  char tmpname[DIRSIZ];
  int where = 0;
 // char* temp;
  //temp = name;
  //printf(tmpname);
  //char* tmpname = (char*)malloc (sizeof(char)*DIRSIZ);  
  if(dp->type != T_DIR)
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de))
  {
   // printf("haha\n");
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    memcut(tmpname, name, where, DIRSIZ + where);
    //printf("iscontinue = %d\n",de.iscontinue);
   // printf("%s\n",tmpname);
   // printf("%s\n",name);
   // memcut(temp,temp,0,DIRSIZ);
    if(namecmp(tmpname, de.name) == 0 && de.iscontinue == 1)
      where = where + DIRSIZ;
    if(namecmp(tmpname, de.name) == 0 && de.iscontinue == 0)
    {
      // entry matches path element
      if(poff)
        *poff = off;/*����ΪĿ¼��Ŀ�е��ֽ�ƫ����*/
      inum = de.inum;
      return iget(dp->dev, inum);
    }
    if(namecmp(tmpname,de.name) == 1)
      where = 0;
  }

  return 0;
}



int find_empty(struct dirent *de, char *name)
{
  return de->inum == 0;
}
// Write a new directory entry (name, inum) into the directory dp.
//������.��..
int dirlink
(struct inode *dp, char *name, uint inum)
{
  uint off;
  struct dirent de;
  struct inode *ip;
  if ((ip = dirlookup(dp, name, 0)) != 0){//查看当前目录是否有重名文件
    iput(ip);
    return -1;
  }
  dirfind(&de, dp, name, 1, &off, find_empty);//寻找一个空的目录项
  strncpy(de.name, name, DIRSIZ);
  de.inum = inum;
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de)){
    panic("dirlink");
  }

  return 0;
}


int
dirlink2(struct inode *dp, char *name, uint inum)/*ͨ�����������ƺ�inode�ţ��ڵ�ǰĿ¼dp�д���һ���µ�Ŀ¼��*/
{
  int off;
  int offf;
  off = 0;
  offf = 0;
  struct dirent de;
  struct dirent dde;
  struct inode *ip;
  int len = strlen(name);
  //printf("dirlink namelen = %d\n",len);
  len = (len + DIRSIZ -1)/DIRSIZ;
 
  //if(len != 0)
   // printf("%d\n",len);
  // Check that name is not present.
  if((ip = dirlookup2(dp, name, 0)) != 0)
  {
    iput(ip);
    return -1;
  }

  // Look for an empty dirent.
  int temp;
  temp = len;
 // printf("size=%d",dp->size);
  for(off = 0; off < dp->size; off += sizeof(de))
  {
    //printf("!\n");
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
      panic("dirlink read1");
    if(de.inum == 0 && temp == len)
    {
      temp--;
      dde = de;
      offf = off;
    }
    if(de.inum ==0 && temp != len)
      temp--;
    if(temp == 0)
    {
      //printf("hahahaha find the place\n");
      de = dde;
      off = offf;
      break;
    }
    if(de.inum!=0)
      temp = len;
  }
  offf = off;
  //printf("offf = %d\n",offf);
  strncpy(de.name, name, DIRSIZ);
  de.inum = inum;
  if(len > 1)
    de.iscontinue = 1;
  if(writei(dp, 0, (uint64)&de, offf, sizeof(de)) != sizeof(de))
    panic("dirlink");
  //printf("dirlink len = %d\n",len);
  int cnum = 0;
  for(int i = 1; i < len;i++)
  {
    offf += sizeof(de);
    //printf("!!!!!!iscontinue%d\n",de.iscontinue);//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    if(readi(dp, 0, (uint64)&de,offf,sizeof(de)) != sizeof(de))
      panic("dirlink read2");
   
   
   // printf("????");
    if (cnum < len -2)
      de.iscontinue = 1;
    cnum = cnum + 1;
    memcut(de.name, name,i*DIRSIZ, (i+1)*DIRSIZ);
    de.inum = inum;
    if(writei(dp, 0, (uint64)&de, offf, sizeof(de)) != sizeof(de))
      panic("dirlink");
  }
  de.iscontinue = 0;
  return 0;
}

// Paths

// Copy the next path element from path into name.
// Return a pointer to the element following the copied one.
// The returned path has no leading slashes,
// so the caller can check *path=='\0' to see if the name is the last one.
// If no name to remove, return 0.
//
// Examples:
//   skipelem("a/bb/c", name) = "bb/c", setting name = "a"
//   skipelem("///a//bb", name) = "bb", setting name = "a"
//   skipelem("a", name) = "", setting name = "a"
//   skipelem("", name) = skipelem("////", name) = 0
//
static char*
skipelem(char *path, char *name)
{
  char *s;
  int len;

  while(*path == '/')
    path++;
  if(*path == 0)
    return 0;
  s = path;
  while(*path != '/' && *path != 0)
    path++;
  len = path - s;
  if(len >= DIRSIZ)
    memmove(name, s, DIRSIZ);
  else {
    memmove(name, s, len);
    name[len] = 0;
  }
  while(*path == '/')
    path++;
  return path;
}


static char*
skipelem2(char *path, char *name)
{
  char *s;
  int len;

  while(*path == '/')
    path++;
  if(*path == 0)
    return 0;
  s = path;
  while(*path != '/' && *path != 0)
    path++;
  len = path - s;
 // if(len >= DIRSIZ)
   // memmove(name, s, DIRSIZ);
 // else {
    memmove(name, s, len);
    name[len] = 0;
 // }
  while(*path == '/')
    path++;
  return path;
}



// Look up and return the inode for a path name.
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
  struct inode *ip, *next;

  if(*path == '/')
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
      iunlockput(ip);
      return 0;
    }
    if(nameiparent && *path == '\0'){
      // Stop one level early.
      iunlock(ip);
      return ip;
    }
    if((next = dirlookup(ip, name, 0)) == 0){
      iunlockput(ip);
      return 0;
    }
    iunlockput(ip);
    ip = next;
  }
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}

static struct inode*
namex2(char *path, int nameiparent, char *name)
{
  //printf("name1 = %s\n",name);
  struct inode *ip, *next;
  /*ȷ������·��*/
  if(*path == '/')/*��Ŀ¼��ʼ*/
    ip = iget(ROOTDEV, ROOTINO);
  else/*��ǰĿ¼��ʼ*/
    ip = idup(myproc()->cwd);

  while((path = skipelem2(path, name)) != 0){/*����·���е�ÿһ��Ԫ��*/
    ilock(ip);/*����ip*/
    if(ip->type != T_DIR){/*����Ŀ¼������ʧ��*/
      iunlockput(ip);
      return 0;
    }
    if(nameiparent && *path == '\0')
    {/*���һ��·��Ԫ��*/
      // Stop one level early.
      iunlock(ip);
      return ip;/*���ؽ�����ip*/
    }
    if((next = dirlookup2(ip, name, 0)) == 0){
      iunlockput(ip);
      return 0;
    }
    //printf("name2 = %s\n",name);

    iunlockput(ip);
    ip = next;/*Ϊ��һ�ε�����׼��*/
  }
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;/*������·��ʱ������ip*/
}

struct inode*
namei(char *path)
{
  char name[DIRSIZ];
  return namex2(path, 0, name);
}

struct inode*
namei2(char *path)
{
  char name[DIRSIZ];
  return namex2(path, 0, name);
}


struct inode*
nameiparent(char *path, char *name)
{
  return namex(path, 1, name);
}

struct inode*
nameiparent2(char *path, char *name)
{
  return namex2(path, 1, name);
}

/*Below is the implementation of the copy,cut and paste functions*/
void
write_cb(struct inode* dp, struct inode* ip, int sstate, char* nname, uint off) {
  if (cb.dir_parent_inode != 0)
    iput(cb.dir_parent_inode);
  cb.dir_parent_inode = dp;
  idup(cb.dir_parent_inode);
  if (cb.dir_inode != 0)
    iput(cb.dir_inode);
  cb.dir_inode = ip;
  idup(cb.dir_inode);
  //cb.fname = nname;
  memset(cb.fname, '\0', sizeof(cb.fname));
  strncpy(cb.fname, nname, sizeof(nname));
  cb.state = sstate;
  cb.off = off;
  //printf("%s %d %d %d %d\n", cb.fname, cb.state,cb.dir_inode->inum,cb.dir_parent_inode->inum,cb.off);
}

void init_cb() {
  cb.dir_inode = 0;
  cb.dir_parent_inode = 0;
  memset(cb.fname, '\0', sizeof(cb.fname));
  //printf("aaa%s\n", cb.fname);
  cb.state = UNUSE;
  cb.off = 0;
}

int
cbunlink() {
  struct inode* p = idup(myproc()->cwd);
  ilock(p);

  //�Ƿ����������ļ����У�
  struct dirent de;
  int off;
  for (off = 0; off < p->size; off += sizeof(de)) {
    if (readi(p, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
      panic("cbcreate read");
    if (namecmp(de.name, cb.fname) == 0) {
      printf("can't cut a file with repeated name!\n");
      iunlockput(p);
      return -1;
    }
  }

  iunlockput(p);

  //struct dirent de;
  ilock(cb.dir_parent_inode);
  if (namecmp(cb.fname, ".") == 0 || namecmp(cb.fname, "..") == 0) {
    iunlock(cb.dir_parent_inode);
    printf("can't unlink the file itself or its parent!\n");
    return -1;
  }
  ilock(cb.dir_inode);
  if (cb.dir_inode->nlink < 1)
    panic("cbunlink: nlink < 1");
  memset(&de, 0, sizeof(de));
  //printf("%d\n", (uint64)&de);
  if (writei(cb.dir_parent_inode, 0, (uint64)&de, cb.off, sizeof(de)) != sizeof(de))
    panic("cbunlink: writei");
  if (cb.dir_inode->type == T_DIR) {
    cb.dir_parent_inode->nlink--;
    if (cb.dir_parent_inode->nlink == 0 && cb.dir_parent_inode->ref > 0) {/*����superblock�б�*/
      lzrni_list_expand(cb.dir_parent_inode->inum);
    }
    iupdate(cb.dir_parent_inode);
  }
  iunlock(cb.dir_parent_inode);

  cb.dir_inode->nlink--;
  if (cb.dir_inode->nlink == 0 && cb.dir_inode->ref > 0) {/*����superblock�б�*/
    lzrni_list_expand(cb.dir_inode->inum);
  }
  iupdate(cb.dir_inode);
  iunlock(cb.dir_inode);
  return 0;
}

int
cblink() {
  struct inode* p = idup(myproc()->cwd);
  ilock(p);
  ilock(cb.dir_inode);

  cb.dir_inode->nlink++;
  lzrni_list_delete(cb.dir_inode->inum);

  iupdate(cb.dir_inode);
  if (cb.dir_inode->type == T_DIR) {

    p->nlink++;
    lzrni_list_delete(p->inum);

    iupdate(p);
  }
  //printf("1");
  //iunlock(cb.dir_inode);
  if (p->dev != cb.dir_inode->dev || dirlink(p, cb.fname, cb.dir_inode->inum) < 0) {
    if (cb.dir_inode->type == T_DIR) {
      p->nlink--;
      iupdate(p);
      if (p->nlink == 0 && p->ref > 0) {
        lzrni_list_expand(p->inum);
      }
    }
    iunlockput(p);
    //ilock(cb.dir_inode);
    cb.dir_inode->nlink--;
    if (cb.dir_inode->nlink == 0 && cb.dir_inode->ref > 0) {//����superblock�б�
      lzrni_list_expand(cb.dir_inode->inum);
    }
    iupdate(cb.dir_inode);
    iunlock(cb.dir_inode);
    return -1;
  }
  //printf("1");
  //ilock(cb.dir_inode);
  //�ø��¡�..����Ӧ�ĸ�Ŀ¼inode��
  if (cb.dir_inode->type == T_DIR) {
    struct dirent de;
    int off;
    for (off = 0; off < cb.dir_inode->size; off += sizeof(de)) {/*Ѱ����Ŀ".."*/
      if (readi(cb.dir_inode, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
        panic("cbdirlink read");
      if (namecmp(de.name, "..") == 0)/*�ҵ�������*/
        break;
    }
    de.inum = p->inum;
    if (writei(cb.dir_inode, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
      panic("cbdirlink");
    iupdate(cb.dir_inode);
  }
  iunlock(cb.dir_inode);
  iunlockput(p);
  return 0;
}

int
isdirempty(struct inode *dp)
{
  int off;
  struct dirent de;

  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
      panic("isdirempty: readi");
    if (de.inum != 0)
      return 0;
  }
  return 1;
}

int
cbcreate() {
  struct inode* p = idup(myproc()->cwd);
  struct inode* ip;
  ilock(p);
  //�Ƿ����������ļ����У�
  struct dirent de;
  int off;
  for (off = 0; off < p->size; off += sizeof(de)) {
    if (readi(p, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
      panic("cbcreate read");
    if (namecmp(de.name, cb.fname) == 0) {
      printf("can't copy a file with repeated name!\n");
      iunlockput(p);
      return -1;
    }
  }
  //Ҫ���Ƶ��Ƿ��ǵ����ļ���
  ilock(cb.dir_inode);
  if (cb.dir_inode->type == T_DIR && !isdirempty(cb.dir_inode)) {
    printf("Copying a folder containing child folders or child files is not supported!\n");
    iunlock(cb.dir_inode);
    iunlockput(p);
    return -1;
  }
  iunlock(cb.dir_inode);
  if ((ip = ialloc(p->dev, cb.dir_inode->type)) == 0)/*û�������Ҳ��ǵ����ļ��еģ�����һ���µ�inode*/
    panic("cbcreate: ialloc");
  ilock(ip);
  ip->major = cb.dir_inode->major;
  ip->minor = cb.dir_inode->minor;
  ip->nlink = 1;
  lzrni_list_delete(ip->inum);
  //printf("%d\n", ip->type);

  if (ip->type != T_DIR) {//����Ŀ¼��ģ�Ҫ������һ���ƹ�ȥ
    uchar dataa[BSIZE];
    if (readi(cb.dir_inode, 0, (uint64)&dataa, 0, cb.dir_inode->size) != cb.dir_inode->size)
      panic("cbcreate read");
    if (writei(ip, 0, (uint64)&dataa, 0, cb.dir_inode->size) != cb.dir_inode->size)
      panic("cbdirlink");
  }

  iupdate(ip);

  if (ip->type == T_DIR) {  // Create . and .. entries./*����µ�inode��Ŀ¼*/
    p->nlink++;  // for ".."
    lzrni_list_delete(p->inum);
    iupdate(p);
    // No ip->nlink++ for ".": avoid cyclic ref count.
    ip->size = sizeof(struct dirent) << 1;// Ϊ�µ�Ŀ¼���� . �� ..
    iupdate(ip);
    struct dirent de;
    for (uint off = 0; off <= sizeof(de); off += sizeof(de)){
      if (readi(ip, 0, (uint64)&de, off, sizeof(struct dirent)) != sizeof(struct dirent)){
        panic("dirinit read failed\n");
      }
      strncpy(de.name, off == 0 ? "." : "..", DIRSIZ);
      de.inum = off == 0 ? ip->inum : p->inum;
      if (writei(ip, 0, (uint64)&de, off, sizeof(de)) != sizeof(de)){
        panic("dirinit write failed\n");
      }
    }
  }
  if (dirlink(p, cb.fname, ip->inum) < 0)
    panic("cbcreate: dirlink");
  iunlockput(ip);
  iunlockput(p);
  return 0;
}

int
clean_cb() {
  if (cb.state == UNUSE || cb.dir_parent_inode == 0 || cb.dir_inode == 0) {
    printf("no file for paste!\n");
    return -1;
  }
  else if (cb.state == CUT) {
    //printf("%d %d", cb.dir_parent_inode->nlink, cb.dir_parent_inode->ref);
    if (cbunlink() < 0) {
      iput(cb.dir_parent_inode);
      iput(cb.dir_inode);
      init_cb();
      printf("cut unlink failed!\n");
      return -1;
    }
    //printf("1");
    if (cblink() < 0) {
      iput(cb.dir_parent_inode);
      iput(cb.dir_inode);
      init_cb();
      printf("cut link failed!\n");
      return -1;
    }
    //printf("1");
  }
  else if (cb.state == COPY) {
    if (cbcreate() < 0) {
      iput(cb.dir_parent_inode);
      iput(cb.dir_inode);
      init_cb();
      printf("copy failed!\n");
      return -1;
    }
  }
  //printf("1");
  //printf("%d %d", cb.dir_parent_inode->nlink, cb.dir_parent_inode->ref);
  iput(cb.dir_parent_inode);
  //printf("1");
  iput(cb.dir_inode);
  init_cb();
  //printf("1");
  return 0;
}

//how to delete a file folder containing child files or file folders?
int
file_unlink(struct inode* dp, struct inode* ip, int off) {
  //parent(dp) and child(ip)
  //dp has been locked
  ilock(ip);
  if (ip->nlink < 1)
    return -1;
  if (ip->type == T_DIR && !isdirempty(ip)) {
    int offf;
    uint temp_off;
    struct dirent dee;
    struct inode* ipp;

    for (offf = 2 * sizeof(dee); offf < ip->size; offf += sizeof(dee)) {
      if (readi(ip, 0, (uint64)&dee, offf, sizeof(dee)) != sizeof(dee))
        return -1;
      if (dee.inum == 0)
        continue;
      if ((ipp = dirlookup(ip, dee.name, &temp_off)) == 0)
        return -1;
      if (file_unlink(ip, ipp, temp_off) < 0)
        return -1;
    }
  }

  struct dirent de;

  memset(&de, 0, sizeof(de));
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    return -1;
  if (ip->type == T_DIR) {
    dp->nlink--;
    if (dp->nlink == 0 && dp->ref > 0) {/*����superblock�б�*/
      lzrni_list_expand(dp->inum);
    }
    iupdate(dp);
  }

  ip->nlink--;
  if (ip->nlink == 0 && ip->ref > 0) {/*����superblock�б�*/
    lzrni_list_expand(ip->inum);
  }
  iupdate(ip);
  iunlockput(ip);

  return 0;
}
