// On-disk file system format.
// Both the kernel and user programs use this header file.
#include "param.h"

#define ROOTINO  1   // root i-number
#define BSIZE 1024  // block size

// Disk layout:
// [ boot block | super block | log | inode blocks |
//                                          free bit map | data blocks]
//
// mkfs computes the super block and builds an initial file system. The
// super block describes the disk layout:
struct superblock {
  uint magic;        // Must be FSMAGIC
  uint size;         // Size of file system image (blocks)
  uint nblocks;      // Number of data blocks
  uint ninodes;      // Number of inodes.
  uint nlog;         // Number of log blocks
  uint logstart;     // Block number of first log block
  uint inodestart;   // Block number of first inode block
  uint bmapstart;    // Block number of first free map block
  /*����Ϊ�����ļ�ϵͳ����ʱ���ӵĳ�Ա����*/
  /*��¼������Ϊ0����������Ϊ0���ļ���inode��inumber��NINODE��param.h����ʾinode������������*/
  uint link_zero_ref_nonzero_inode_list[NINODE];
  int lzrni_list_num;/*��һ�������б���Ԫ�ص�����*/
};

#define FSMAGIC 0x10203040

#define NDIRECT 11
#define NINDIRECT (BSIZE / sizeof(uint))
#define NININDIRECT (NINDIRECT * NINDIRECT)
#define MAXFILE (NDIRECT + NINDIRECT + NININDIRECT)

// On-disk inode structure
struct dinode {
  short type;           // File type
  short major;          // Major device number (T_DEVICE only)
  short minor;          // Minor device number (T_DEVICE only)
  short nlink;          // Number of links to inode in file system
  uint size;            // Size of file (bytes)
  uint addrs[NDIRECT+2];   // Data block addresses
};

// Inodes per block.
#define IPB           (BSIZE / sizeof(struct dinode))

// Block containing inode i
#define IBLOCK(i, sb)     ((i) / IPB + sb.inodestart)

// Bitmap bits per block
#define BPB           (BSIZE*8)

// Block of free map containing bit for block b
#define BBLOCK(b, sb) ((b)/BPB + sb.bmapstart)

// Directory is a file containing a sequence of dirent structures.
#define DIRSIZ 12

struct dirent {
  ushort inum;
  char name[DIRSIZ];
  short iscontinue;
};

#define UNUSE  0
#define COPY   1
#define CUT    2

//新添MAXOFF,MAXFSIZE
#define MAXOFF 0xFFFF
#define MAXFSIZE ((NDIRECT + NINDIRECT + NININDIRECT) * BSIZE)//直接加间接块能存储的最多大小
//哈希参数
#define N_DIRECT_HASH_BUCKET 171 // 每个直接块中的哈希桶 4 个dirent，在直接块首放 . 和 .. , 实际有176个
#define N_INDIRECT_HASH_BUCKET 2047 // 每个间接块中的哈希桶可以容纳 8 个dirent， 实际有2048个
#define N_ININDIRECT_HASH_BUCKET 8191 // 每个间接间接块中的哈希桶可以容纳 512 个dirent， 实际有8192个
#define SZ_DIRECT_BUCKET ((NDIRECT * BSIZE / 176)) // 4 * sizeof(struct dirent)
#define DIRECT_BUCKET_OFF(n) (((n)*SZ_DIRECT_BUCKET) + 64 + 64*4) //中间留有4个哈希桶空间，即4*4个目录项位置

// 如果对某一目录项名直接和间接块的哈希桶都没空才使用二次间接块
#define N_OVERFLOW_AREA ( 8 *sizeof(struct dirent))
#define SZ_INDIRECT_BUCKET (((NINDIRECT * BSIZE - N_OVERFLOW_AREA) / N_INDIRECT_HASH_BUCKET)) // 8 * sizeof(struct dirent)
#define SZ_ININDIRECT_BUCKET ( 512 * sizeof(struct dirent)) // 512 * sizeof(struct dirent)
#define INDIRECT_BUCKET_OFF(n) (((n)*SZ_INDIRECT_BUCKET) + DIRECT_BUCKET_OFF((N_DIRECT_HASH_BUCKET + 1)))
#define ININDIRECT_BUCKET_OFF(n) (((n)*SZ_ININDIRECT_BUCKET) + INDIRECT_BUCKET_OFF((N_INDIRECT_HASH_BUCKET + 1 + 1)))